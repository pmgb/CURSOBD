﻿$(document).ready(function () {

    function GetMarcas() {

        // PREPARAR LA LLAMA AL API
        var urlAPI = 'http://localhost:52673/api/marcas';

        // PROCESAR LOS RESULTADOS

    }

});