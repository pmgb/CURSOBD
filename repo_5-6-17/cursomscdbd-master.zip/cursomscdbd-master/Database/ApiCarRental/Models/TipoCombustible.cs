﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApiCarRental
{
    public class TipoCombustible
    {
        public long id { get; set; }
        public string denominacion { get; set; }
    }
}
